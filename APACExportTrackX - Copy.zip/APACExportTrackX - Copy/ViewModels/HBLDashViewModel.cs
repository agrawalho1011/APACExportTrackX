﻿namespace APACExportTrackX.ViewModels
{
    public class HBLDashViewModel
    {
        public string Id { get; set; }
        public string FileId { get; set; }
        public string HBLNumber { get; set; }
        public string FileNumber { get; set; }
        public string? BookingNo { get; set; }
        public string? ContainerNo { get; set; }
        public string? POD { get; set; }
        public string? CustomerName { get; set; }
        public string? Activity { get; set; }
        public string? Status { get; set; }
        public string? StatusId { get; set; }
        public string? User { get; set; }
        public string? Comment { get; set; }
        public string? ActivityType { get; set; }
        public DateTime? EnterDate { get; set; }
        public DateTime? StartDate { get; set; }
        public DateTime? EndDate { get; set; }
        public string? CurrentUser { get; set; }
        public string? Role { get; set; }
    }
}
