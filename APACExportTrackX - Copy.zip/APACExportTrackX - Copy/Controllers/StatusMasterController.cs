﻿using APACExportTrackX.DataModel;
using APACExportTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using System.Threading.Tasks;

namespace APACExportTrackX.Controllers
{
	public class StatusMasterController : Controller
	{
		private readonly ApplicationDBContext _context;

		public StatusMasterController(ApplicationDBContext context)
		{
			_context = context;
		}

		// GET: StatusMaster
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Index()
		{
			ViewData["Status"] = _context.StatusMaster.ToList();
			return View(await _context.StatusMaster.ToListAsync());
		}

		// GET: StatusMaster/Details/5
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Details(string? id)
		{
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var statusMaster = await _context.StatusMaster
				.FirstOrDefaultAsync(m => m.Id == id);
			if (statusMaster == null)
			{
				return NotFound();
			}

			return View(statusMaster);
		}

		// GET: StatusMaster/Create
		[Authorize(Roles = "Supervisor,Manager")]
		public IActionResult Create()
		{
			return View();
		}

		// POST: StatusMaster/Create
		// To protect from overposting
		[HttpPost]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Create([Bind("Id,Status,Value")] StatusMaster statusMaster)
		{
			bool success = false;
			var result = new { success = success, message = "Error while processing the request." };
			var status = _context.StatusMaster.Where(x => x.Status == statusMaster.Status).FirstOrDefault();

			if (ModelState.IsValid)
			{
				if(status == null)
                {
					_context.Add(statusMaster);
					await _context.SaveChangesAsync();
					success = true;
				}
                else
                {
					success = false;
				}
			}

			if (success == true)
			{
				result = new { success = success, message = "success" };
			}
			else if (status != null && success == false)
            {
				result = new { success = success, message = "duplicate" };
			}
			else
			{
				result = new { success = success, message = "error" };
			}
			return Json(result);
		}

		// GET: StatusMaster/Edit/5
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Edit(string? id)
		{

			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var statusMaster = await _context.StatusMaster.FindAsync(id);
			if (statusMaster == null)
			{
				return NotFound();
			}
			return View(statusMaster);
		}

		// POST: StatusMaster/Edit/5
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Edit(string id, [Bind("Id,Status,Value")] StatusMaster statusMaster)
		{
			bool success = false;
			var result = new { success = success, message = "Error while processing the request." };
			if (id != statusMaster.Id)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(statusMaster);
					await _context.SaveChangesAsync();
					success = true;
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!StatusMasterExists(statusMaster.Id))
					{
						return NotFound();
						success = false;
					}
					else
					{
						throw;
						success = false;
					}
				}
				//return RedirectToAction(nameof(Index));
				if (success == true)
				{
					result = new { success = success, message = "success" };
				}
				else
				{
					result = new { success = success, message = "error" };
				}
			}
			return Json(result);
		}

		// GET: StatusMaster/Delete/5
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Delete(string? id)
		{
			if (id == null || id.Trim()=="")
			{
				return NotFound();
			}

			var statusMaster = await _context.StatusMaster
				.FirstOrDefaultAsync(m => m.Id == id);
			if (statusMaster == null)
			{
				return NotFound();
			}

			return View(statusMaster);
		}

		// POST: StatusMaster/Delete/5
		[HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> DeleteConfirmed(string id)
		{
			var statusMaster = await _context.StatusMaster.FindAsync(id);
			_context.StatusMaster.Remove(statusMaster);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}
		private bool StatusMasterExists(string id)
		{
			return _context.StatusMaster.Any(e => e.Id == id);
		}
	}
}