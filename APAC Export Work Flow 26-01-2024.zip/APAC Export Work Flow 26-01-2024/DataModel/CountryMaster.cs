﻿using System;
using System.Collections.Generic;

namespace APACExportTrackX.DataModel
{
    public partial class CountryMaster
    {
        public string Id { get; set; } = Guid.NewGuid().ToString();

        public string CountryName { get; set; } = null!;
        public bool? IsActive { get; set; } = true;
        public bool? IsDelete { get; set; } = false;
        public virtual ICollection<FileMaster> FileMasters { get; } = new List<FileMaster>();
    }
}