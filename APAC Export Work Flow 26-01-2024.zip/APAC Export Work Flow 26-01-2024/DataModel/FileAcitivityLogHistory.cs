﻿using System.ComponentModel.DataAnnotations.Schema;

namespace APACExportTrackX.DataModel
{
    public class FileAcitivityLogHistory
    {
        public string? Id { get; set; } = Guid.NewGuid().ToString();

        public string? FileLogId { get; set; }

        public string? ActivityId { get; set; }

        public string? StatusId { get; set; }

        public string? Comment { get; set; }

        public string? UserId { get; set; } 
        public string? Roe { get; set; }

        public DateTime? StartDate { get; set; }

        public DateTime? EndDate { get; set; }

        [ForeignKey("UserId")]
        public virtual ApplicationUser ApplicationUser { get; set; } = null!;

        [ForeignKey("FileLogId")]
        public virtual FileActivityLog FileActivityLog { get; set; } = null!;

        [ForeignKey("ActivityId")]
        public virtual ActivityMaster Activity { get; set; } = null!;
        public virtual StatusMaster Status { get; set; }

       

    }
}
