﻿namespace APACExportTrackX.ViewModels
{
    public class HBLReportViewModel
    {
        public DateTime? EnterDate { get; set; }
        public string FileNumber { get; set; }
        public string? ContainerNo { get; set; }
        public string? BookingNo { get; set; }
        public string HBLNumber { get; set; }
        public string? CustomerName { get; set; }
        public string? User { get; set; }
        public string? Activity { get; set; }
        public string? Status { get; set; }
        public string? Comment { get; set; }
        public int? TBL { get; set; }
        public int? LBL { get; set; }
        public int? TotalHBL { get; set; }
        
    }
}
