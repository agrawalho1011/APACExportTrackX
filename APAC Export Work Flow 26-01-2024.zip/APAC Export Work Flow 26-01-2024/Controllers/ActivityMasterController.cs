﻿using APACExportTrackX.DataModel;
using APACExportTrackX.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace APACExportTrackX.Controllers
{
	public class ActivityMasterController : Controller
	{
		private readonly ApplicationDBContext _context;

		public ActivityMasterController(ApplicationDBContext context)
		{
			_context = context;
		}

		// GET: ActivityMaster
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Index()
		{
			ViewData["Activity"] = _context.ActivityMaster.Where(x => x.IsDelete == false).OrderBy(x => x.FileSequence).ToList();
			return View(await _context.ActivityMaster.Where(x => x.IsDelete == false).ToListAsync());
		}

		[Authorize(Roles = "Supervisor,Manager")]
		// GET: ActivityMaster/Create
		public IActionResult Create()
		{
			return View(new ActivityMaster());
		}

		// POST: ActivityMaster/Create
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Create([Bind("Id,NameOfActivity,ActivityType,Source")] ActivityMaster activityMaster)
		{
			bool success = false;
			var result = new { success = success, message = "Error while processing the request." };
			var activity = _context.ActivityMaster.Where(x => x.NameOfActivity == activityMaster.NameOfActivity && x.ActivityType == activityMaster.ActivityType && x.IsActive == true && x.IsDelete == false).FirstOrDefault();

			if (ModelState.IsValid)
			{
				if (activity == null)
				{
					_context.Add(activityMaster);
					await _context.SaveChangesAsync();
					success = true;
				}
				else
				{
					success = false;
				}
			}
			if (success == true)
			{
				result = new { success = success, message = "success" };
			}
			else if (activity != null && success == false)
			{
				result = new { success = success, message = "duplicate" };
			}
			else
			{
				result = new { success = success, message = "error" };
			}
			return Json(result);
		}

		// GET: ActivityMaster/Edit/5
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Edit(string? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var activityMaster = await _context.ActivityMaster.FindAsync(id);
			if (activityMaster == null)
			{
				return NotFound();
			}
			return View(activityMaster);
		}

		// POST: ActivityMaster/Edit/5
		// To protect from overposting attacks, enable the specific properties you want to bind to, for 
		// more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
		[HttpPost]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Edit(string id, [Bind("Id,NameOfActivity,ActivityType,Source")] ActivityMaster activityMaster)
		{
			bool success = false;
			var result = new { success = success, message = "Error while processing the request." };
			if (id != activityMaster.Id)
			{
				return NotFound();
			}

			if (ModelState.IsValid)
			{
				try
				{
					_context.Update(activityMaster);
					await _context.SaveChangesAsync();
					success = true;
				}
				catch (DbUpdateConcurrencyException)
				{
					if (!ActivityMasterExists(activityMaster.Id))
					{
						return NotFound();
						success = false;
					}
					else
					{
						throw;
						success = false;
					}
				}
				if (success == true)
				{
					result = new { success = success, message = "success" };
				}			
				else
				{
					result = new { success = success, message = "error" };
				}
				//return RedirectToAction(nameof(Index));
			}
			return Json(result);
		}

		// GET: ActivityMaster/Delete/5
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> Delete(string? id)
		{
			if (id == null)
			{
				return NotFound();
			}

			var activityMaster = await _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false)
                .FirstOrDefaultAsync(m => m.Id == id);
			if (activityMaster == null)
			{
				return NotFound();
			}

			return View(activityMaster);
		}

        //Insert activity 
        [Authorize(Roles = "Supervisor,Manager")]
        public JsonResult InsertActivity(ActivityMaster activityMaster)
        {
            string Msg = "";
            if (ModelState.IsValid)
            {
                var Isexits = _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false && x.NameOfActivity == activityMaster.NameOfActivity && x.ActivityType == activityMaster.ActivityType).FirstOrDefault();

                if (Isexits == null)
                {
                    _context.Add(activityMaster);
                    _context.SaveChanges();
                    Msg = "Activity Insert Successfully";
                }
                else
                {
                    Msg = "Activity already added";
                }
            }
            else
            {
                Msg = "Name of Activity and ActivityType not empty";
            }
            return Json(Msg);
        }

        // POST: ActivityMaster/Delete/5
        [HttpPost, ActionName("Delete")]
		[ValidateAntiForgeryToken]
		[Authorize(Roles = "Supervisor,Manager")]
		public async Task<IActionResult> DeleteConfirmed(string id)
		{
			var activityMaster = await _context.ActivityMaster.FindAsync(id);
			_context.ActivityMaster.Remove(activityMaster);
			await _context.SaveChangesAsync();
			return RedirectToAction(nameof(Index));
		}

		private bool ActivityMasterExists(string id)
		{
			return _context.ActivityMaster.Where(x => x.IsActive == true && x.IsDelete == false).Any(e => e.Id == id);
		}
	}
}
